DROP TABLE `#__postman_log`;
DROP TABLE `#__postman_tickets`;
DROP TABLE `#__postman_newsletters`;
DROP TABLE `#__postman_newsgroups`;
DROP TABLE `#__postman_subscribers`;
DROP TABLE `#__postman_newsgroups_subscribers;